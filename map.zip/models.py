# This is an auto-generated Django model module created by ogrinspect.
from django.contrib.gis.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from reversion import revisions as reversion
from django.core.exceptions import ValidationError
from django.db.models import signals
from django.core.mail import send_mail
from inventory.models import Assets, Users, Models, Categories
from django.db.models import Prefetch
from autoslug import AutoSlugField
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill
from imagekit.models import ImageSpecField
import os

from uuid import uuid4
class WorldBorder(models.Model):
    fips = models.CharField(max_length=2)
    iso2 = models.CharField(max_length=2)
    iso3 = models.CharField(max_length=3)
    un = models.IntegerField()
    name = models.CharField(max_length=50)
    area = models.IntegerField()
    pop2005 = models.IntegerField()
    region = models.IntegerField()
    subregion = models.IntegerField()
    lon = models.FloatField()
    lat = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'World'
        get_latest_by = "created_at"
        # order_with_respect_to = 'question'
        ordering = ['updated_at']  # ascending
        # ordering = ['-pub_date', 'author'] # To order by pub_date descending, then by author ascending, use this
        # permissions = (("can_deliver_pizzas", "Can deliver pizzas"),)
        # verbose_name = "pizza"
        # index_together = [
        #     ["pub_date", "deadline"],
        # ]

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        super(WorldBorder, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(WorldBorder, self).save(*args, **kwargs)


reversion.register(WorldBorder, exclude=('geom', 'lat', 'long'))

# Auto-generated `LayerMapping` dictionary for WorldBorder model
worldborder_mapping = {
    'fips': 'FIPS',
    'iso2': 'ISO2',
    'iso3': 'ISO3',
    'un': 'UN',
    'name': 'NAME',
    'area': 'AREA',
    'pop2005': 'POP2005',
    'region': 'REGION',
    'subregion': 'SUBREGION',
    'lon': 'LON',
    'lat': 'LAT',
    'geom': 'MULTIPOLYGON',
}


class Country(models.Model):
    gadmid = models.IntegerField()
    iso = models.CharField(max_length=5)
    name = models.CharField(max_length=54)
    iso2 = models.CharField(max_length=4)
    www = models.CharField(max_length=2)
    sqkm = models.FloatField()
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'Country'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


reversion.register(Country)

# Auto-generated `LayerMapping` dictionary for Country model
country_mapping = {
    'gadmid': 'GADMID',
    'iso': 'ISO',
    'name': 'NAME',
    'iso2': 'ISO2',
    'www': 'WWW',
    'sqkm': 'SQKM',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}


class Province(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=75)
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'provinces'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


# Auto-generated `LayerMapping` dictionary for Province model
province_mapping = {
    'id': 'ID',
    'name': 'NAME',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}
reversion.register(Province)


class School(models.Model):
    county = models.CharField(max_length=254)
    subcounty = models.CharField(max_length=254)
    zone = models.CharField(max_length=254)
    runningsn = models.IntegerField()
    zonesn = models.IntegerField()
    schoolid = models.IntegerField()
    name = models.CharField(max_length=254)
    lat = models.FloatField( null=True, blank=True)
    long = models.FloatField( null=True, blank=True)
    headmaster = models.CharField(max_length=254, null=True, blank=True)
    headnumber = models.IntegerField(null=True, blank=True)
    senrol = models.IntegerField(verbose_name='School Enrolment', null=True, blank=True)
    c1enrol = models.IntegerField(verbose_name='Class One Enrolment')
    teachers = models.IntegerField(verbose_name='No Of Trained Teachers', null=True, blank=True)
    geom = models.PointField(srid=4326, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateField(auto_now=True, null=True)
    # slug = AutoSlugField(populate_from='name',unique=True)
    # @models.permalink
    # def get_absolute_url(self):
    #     return ('school', (), {
    #         'slug': self.slug,
    #         'id': self.id,
    #     })

    class Meta:
        default_related_name = 'schools'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


        # Auto-generated `LayerMapping` dictionary for School model


school_mapping = {
    'county': 'county',
    'subcounty': 'subcounty',
    'zone': 'zone',
    'runningsn': 'runningsn',
    'zonesn': 'zonesn',
    'schoolid': 'schoolid',
    'name': 'name',
    'lat': 'lat',
    'long': 'long',
    'headmaster': 'headmaster',
    'headnumber': 'headnumber',
    'senrol': 'senrol',
    'c1enrol': 'c1enrol',
    'teachers': 'teachers',
    'geom': 'POINT',
}
reversion.register(School)


class County(models.Model):
    # id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=75)
    type = models.CharField(max_length=50)
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    schools = models.ManyToManyField(School, through='CountySchool', related_name='CountySchools')
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)
    # slug = AutoSlugField(populate_from='name',unique=True,max_length=255)
    class Meta:
        default_related_name = 'counties'
        get_latest_by = "created_at"
        ordering = ['updated_at']
    #
    # @models.permalink
    # def get_absolute_url(self):
    #     return ('county', (), {
    #         'slug': self.slug,
    #         'id': self.id,
    #     })

    def __str__ (self):
        return self.name

    @property
    def all_schools (self):
        return ', '.join(school.name for school in self.schools.all())

    @property
    def all_schools_count (self):
        schools = self.schools.all()
        return schools.count()

    @property
    def ldd_count (self):
        schoolusers = Users.objects.filter(location__name__contains=self.name, deleted_at__isnull=True,
                                           last_name__exact='Primary School')
        ldds = Assets.objects.filter(assigned_to__id__in=schoolusers, model__modelno__iexact="TR10RS1",
                                     model__deleted_at__isnull=True, deleted_at__isnull=True)

        return ldds.count()

    @property
    def tdd_count (self):
        schoolusers = Users.objects.filter(location__name__contains=self.name, deleted_at__isnull=True,
                                           last_name__exact='Primary School')
        tdds = Assets.objects.filter(assigned_to__id__in=schoolusers, model__modelno__iexact="SF40BA",
                                     model__deleted_at__isnull=True, deleted_at__isnull=True)

        return tdds.count()
    @property
    def projector_count (self):
        schoolusers = Users.objects.filter(location__name__contains=self.name, deleted_at__isnull=True,
                                           last_name__exact='Primary School')
        projectors = Assets.objects.filter(assigned_to__id__in=schoolusers, model__modelno__iexact="EB-X04",
                                           model__deleted_at__isnull=True, deleted_at__isnull=True)

        return projectors.count()
# Auto-generated `LayerMapping` dictionary for County model
county_mapping = {
    # 'id': 'ID',
    'name': 'NAME',
    'type': 'TYPE',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}
reversion.register(County)


class CountySchool(models.Model):
    county = models.ForeignKey(County, on_delete=models.CASCADE)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'countyschools'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.school.name


reversion.register(CountySchool)


class Division(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=75)
    type = models.CharField(max_length=50)
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'divisions'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


# Auto-generated `LayerMapping` dictionary for Division model
division_mapping = {
    'id': 'ID',
    'name': 'NAME',
    'type': 'TYPE',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}
reversion.register(Division)


class Location(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    type = models.CharField(max_length=25)
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'locations'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


# Auto-generated `LayerMapping` dictionary for Location model
location_mapping = {
    'id': 'ID',
    'name': 'NAME',
    'type': 'TYPE',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}

reversion.register(Location)


class Sublocation(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=75)
    type = models.CharField(max_length=25)
    shape_leng = models.FloatField()
    shape_area = models.FloatField()
    geom = models.MultiPolygonField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'sublocations'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name


# Auto-generated `LayerMapping` dictionary for Sublocation model
sublocation_mapping = {
    'id': 'ID',
    'name': 'NAME',
    'type': 'TYPE',
    'shape_leng': 'Shape_Leng',
    'shape_area': 'Shape_Area',
    'geom': 'MULTIPOLYGON',
}
reversion.register(Sublocation)


class Tti(models.Model):
    name = models.CharField(max_length=254)
    county = models.CharField(max_length=254)
    address = models.CharField(max_length=254)
    email = models.CharField(max_length=254)
    lat = models.FloatField()
    long = models.FloatField()
    geom = models.PointField(srid=4326)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'ttis'
        get_latest_by = "created_at"
        ordering = ['updated_at']


# Auto-generated `LayerMapping` dictionary for Tti model
tti_mapping = {
    'name': 'name',
    'county': 'county',
    'address': 'address',
    'email': 'email',
    'lat': 'lat',
    'long': 'long',
    'geom': 'POINT',
}
reversion.register(Tti)


class Phase(models.Model):
    name = models.CharField(max_length=20)
    code = models.CharField(max_length=10)
    schools = models.ManyToManyField(School, through='PhaseSchool')
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        default_related_name = 'phases'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name:
            error_message = "Phase Name cannot be blank"
            raise ValidationError({
                'name': error_message,

            })
        if not self.code:
            error_message = "Code cannot be blank"
            raise ValidationError({
                'code': error_message,

            })

        super(Phase, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(Phase, self).save(*args, **kwargs)


reversion.register(Phase)


class PhaseSchool(models.Model):
    phase = models.ForeignKey(Phase, on_delete=models.CASCADE)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'phaseschools'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.school.name


reversion.register(PhaseSchool)


class Activity(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'activities'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "Activity Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,

            })
        super(Activity, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(Activity, self).save(*args, **kwargs)


reversion.register(Activity)


class Component(models.Model):  # training, delivery, installation, repair, call center
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'components'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "Component Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,

            })
        super(Component, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(Component, self).save(*args, **kwargs)


reversion.register(Component)


class TaskStatus(models.Model):  # completed, not completed, delayed
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'taskstatuses'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "TaskStatus Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,

            })
        super(TaskStatus, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(TaskStatus, self).save(*args, **kwargs)


reversion.register(TaskStatus)


class NumberType(models.Model):  # teacher, device
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'numbertypes'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "NumberType Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,

            })
        super(NumberType, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(NumberType, self).save(*args, **kwargs)


reversion.register(NumberType)


class DeviceType(models.Model):
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'devicetypes'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "DeviceType Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,

            })
        super(DeviceType, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(DeviceType, self).save(*args, **kwargs)


reversion.register(DeviceType)


def path_and_rename (self, filename):
    upload_to = 'avatars'
    ext = filename.split('.')[-1]
    # get filename
    # if self.pk:
    filename = '{}.{}'.format(self.user, ext)
    # else:
    # set filename as random string
    # filename = '{}.{}'.format(self.user, ext)
    # return the whole path to the file
    return os.path.join(upload_to, filename)

class Profile(models.Model):


    identification_number = models.CharField(max_length=200, blank=True, null=True)
    passport_number = models.CharField(max_length=200, blank=True, null=True)
    mobile_telephone_number = models.CharField(max_length=200, blank=True, null=True)
    staff_number = models.CharField(max_length=200, null=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    avatar = models.ImageField(upload_to=path_and_rename)
    avatar_thumbnail = ImageSpecField(source='avatar',
                                      processors=[ResizeToFill(100, 50)],
                                      format='png',
                                      options={'quality': 100})

    class Meta:
        default_related_name = 'profile'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.user.username


        #
        # def clean (self, *args, **kwargs):
        #     # add custom validation here
        #     # if not self.identification_number or not self.passport_number or not self.mobile_telephone_number or not self.staff_number:
        #     #     # error_message="identification number cannot be blank"
        #     #     raise ValidationError({
        #     #         'identification_number': 'identification_number cannot be blank',
        #     #         'passport_number': 'passport_number cannot be blank',
        #     #         'mobile_telephone_number': 'mobile_telephone_number cannot be blank',
        #     #         'staff_number': 'staff_number cannot be blank',
        #     #
        #     #     })
        #     super(Profile, self).clean(*args, **kwargs)
        #
        # def save (self, *args, **kwargs):
        #
        #     self.clean()
        #     super(Profile, self).save(*args, **kwargs)


reversion.register(Profile)


@receiver(post_save, sender=User)
def create_user_profile (sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile (sender, instance, **kwargs):
    instance.profile.save()


class Venue(models.Model):
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'numbertypes'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "Venue Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,
            })
        super(Venue, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(Venue, self).save(*args, **kwargs)


reversion.register(Venue)


class ConsortiumPartner(models.Model):
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__ (self):
        self.name

    class Meta:
        default_related_name = 'venues'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.name or not self.description:
            error_message = "Consortium Partner Name or Description cannot be blank"
            raise ValidationError({
                'name': error_message,
                'description': error_message,
            })
        super(ConsortiumPartner, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(ConsortiumPartner, self).save(*args, **kwargs)


reversion.register(ConsortiumPartner)


class Task(models.Model):
    component = models.ForeignKey(Component, on_delete=models.CASCADE)  #
    task_description = models.CharField(max_length=200)
    number_type = models.ForeignKey(NumberType, on_delete=models.CASCADE)
    number = models.CharField(max_length=200)
    venue = models.ForeignKey(Venue, on_delete=models.CASCADE)
    start_date = models.DateField('start date')
    end_date = models.DateField('end date')
    next_planned_activity = models.CharField(max_length=200)
    next_planned_activity_start_date = models.DateField('next planned activity start')
    next_planned_activity_end_date = models.DateField('next planned activity end')
    responsible = models.ForeignKey(User, on_delete=models.CASCADE)
    task_status = models.ForeignKey(TaskStatus, on_delete=models.CASCADE)
    consortium_partner = models.ForeignKey(ConsortiumPartner, on_delete=models.CASCADE)
    challenge = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    # @staticmethod
    # def autocomplete_search_fields():
    #     return ("id__iexact", "component__icontains",)

    class Meta:
        default_related_name = 'tasks'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.task_description

    #
    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.task_description or not self.start_date or not self.end_date or not self.next_planned_activity or not self.responsible:
            # error_message="identification number cannot be blank"
            raise ValidationError({
                'task_description': 'task_description cannot be blank',
                'start_date': 'start_date cannot be blank',
                'end_date': 'end_date cannot be blank',
                'next_planned_activity': 'next_planned_activity cannot be blank',
                'responsible': 'responsible person cannot be blank',

            })
        super(Task, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(Task, self).save(*args, **kwargs)


reversion.register(Task)


class DeviceSpecification(models.Model):
    feature = models.CharField(max_length=200)
    specification = models.CharField(max_length=255)
    devicetype = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__ (self):
        self.feature
        # def clean (self, *args, **kwargs):
        #     # add custom validation here
        #     if not self.feature or not self.specification or not self.devicetype:
        #         # error_message="identification number cannot be blank"
        #         raise ValidationError({
        #             'feature': 'feature cannot be blank',
        #             'specification': 'specification cannot be blank',
        #             'devicetype': 'devicetype cannot be blank',
        #
        #         })
        #     super(DeviceSpecification, self).clean(*args, **kwargs)
        #
        # def save (self, *args, **kwargs):
        #     self.full_clean()
        #     super(DeviceSpecification, self).save(*args, **kwargs)


reversion.register(DeviceSpecification)


class InstallationVerification(models.Model):
    YES = 'YES'
    NO = 'NO'
    CONFORMS_CHOICES = (
        (YES, 'Yes'),
        (NO, 'No'),
    )
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    devicespecification = models.ForeignKey(DeviceSpecification, on_delete=models.CASCADE)
    conformity = models.CharField(
        choices=CONFORMS_CHOICES,
        default=YES,
        max_length=4

    )
    remark = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__ (self):
        self.school + " " + ' ' + self.devicespecification + ' ' + self.conformity

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.school or not self.devicespecification or not self.conformity:
            # error_message="identification number cannot be blank"
            raise ValidationError({
                'school': 'school cannot be blank',
                'devicespecification': 'devicespecification cannot be blank',
                'conformity': 'conformity cannot be blank',

            })
        super(InstallationVerification, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(InstallationVerification, self).save(*args, **kwargs)


reversion.register(InstallationVerification)


class InstalledDevice(models.Model):
    YES = 'YES'
    NO = 'NO'
    connectingtonetsupportsoftware = (
        (YES, 'Yes'),
        (NO, 'No'),
    )
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    device_type = models.ForeignKey(DeviceType, on_delete=models.CASCADE)
    number_of_devices_installed = models.IntegerField(default=0)
    number_of_devices_connecting_to_access_point = models.IntegerField(blank=True, null=True)
    connecting_to_netsupport_software = models.CharField(
        choices=connectingtonetsupportsoftware,
        default=YES,
        max_length=4

    )

    number_of_devices_working = models.IntegerField(default=0)
    number_of_devices_not_working = models.IntegerField(default=0)
    remarks = models.CharField(max_length=200, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'installeddevices'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.device_type.name

    def clean (self, *args, **kwargs):
        if not self.number_of_devices_installed or not self.number_of_devices_working or not self.number_of_devices_not_working:
            raise ValidationError({
                'number_of_devices_installed': 'number_of_devices_installed cannot be blank',
                'number_of_devices_working': 'number_of_devices_working cannot be blank',
                'number_of_devices_not_working': 'number_of_devices_not_working cannot be blank',

            })
        super(InstalledDevice, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(InstalledDevice, self).save(*args, **kwargs)


reversion.register(InstalledDevice)


class InstallationReadiness(models.Model):
    PREPARED = 'PREPARED'
    NOTPREPARED = 'NOTPREPARED'
    GOOD = 'Good'
    BAD = 'Bad'
    PREPARED_CHOICES = (
        (PREPARED, 'Prepared'),
        (NOTPREPARED, 'Not Prepared'),
    )
    GOODBAD_CHOICES = (
        (GOOD, 'Good'),
        (BAD, 'Bad'),
    )

    school = models.ForeignKey(School, on_delete=models.CASCADE)
    prepared_for_installation = models.CharField(
        choices=PREPARED_CHOICES,
        default=PREPARED,
        max_length=15,

    )
    recommended_correction = models.CharField(max_length=200)
    classroom_security_condition = models.CharField(
        choices=GOODBAD_CHOICES,
        default=GOOD,
        max_length=4

    )
    charging_points_condition = models.CharField(
        choices=GOODBAD_CHOICES,
        default=GOOD,
        max_length=4,

    )
    teacher_preparedness = models.CharField(
        max_length=15,
        choices=PREPARED_CHOICES,
        default=PREPARED,

    )
    school_access_road_condition = models.CharField(
        choices=GOODBAD_CHOICES,
        default=GOOD,
        max_length=4

    )
    school_access_security_condition = models.CharField(
        choices=GOODBAD_CHOICES,
        default=GOOD,
        max_length=4

    )
    remarks = models.CharField(max_length=200, blank=True, null=True)
    challenge = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'readiness'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.prepared_for_installation

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.recommended_correction or not self.classroom_security_condition or not self.charging_points_condition or not self.teacher_preparedness or not self.school_access_road_condition or not self.school_access_security_condition or not self.challenge:
            # error_message="identification number cannot be blank"
            raise ValidationError({
                'recommended_correction': 'recommended_correction cannot be blank',
                'classroom_security_condition': 'classroom_security_condition cannot be blank',
                'charging_points_condition': 'charging_points_condition cannot be blank',
                'teacher_preparedness': 'teacher_preparedness cannot be blank',
                'school_access_road_condition': 'school_access_road_condition cannot be blank',
                'challenge': 'challenge  cannot be blank'

            })
        super(InstallationReadiness, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(InstallationReadiness, self).save(*args, **kwargs)


reversion.register(InstallationReadiness)


class ActivitySchedule(models.Model):
    date = models.DateField('date scheduled')
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    number_of_devices = models.IntegerField(default=0, null=True, blank=True)
    start_time = models.TimeField()
    end_time = models.TimeField()
    technician = models.ForeignKey(User, on_delete=models.CASCADE)
    school_contact_person_name = models.CharField(max_length=200, null=True, blank=True)
    school_contact_person_mobile_number = models.IntegerField(default=0, null=True, blank=True)
    remarks = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        default_related_name = 'schedules'
        get_latest_by = "created_at"
        ordering = ['updated_at']

    def __str__ (self):
        return self.school.name

    def clean (self, *args, **kwargs):
        # add custom validation here
        if not self.activity or self.number_of_devices or not self.start_time or not self.end_time or not self.school_contact_person_name or not self.school_contact_person_mobile_number:
            # error_message="identification number cannot be blank"
            raise ValidationError({
                'school': 'school cannot be blank',
                'date': 'date  cannot be blank',
                'activity': 'activity  cannot be blank',
                'number_of_devices': 'number_of_devices cannot be blank',
                'start_time': 'start_installation_time cannot be blank',
                'end_time': 'end_installation_time cannot be blank',
                'school_contact_person_name': 'school_contact_person_name cannot be blank',
                'school_contact_person_mobile_number': 'school_contact_person_mobile_number cannot be blank',

            })
        super(ActivitySchedule, self).clean(*args, **kwargs)

    def save (self, *args, **kwargs):
        self.full_clean()
        super(ActivitySchedule, self).save(*args, **kwargs)


reversion.register(ActivitySchedule)


# # Returns the string representation of the model.
# def __str__(self):              # __unicode__ on Python 2
#    return self.name


# def notify_admin(sender, instance, created, **kwargs):
#     '''Notify the administrator that a new user has been added.'''
#     if created:
#        subject = 'New user created'
#        message = 'User %s was added' % instance.username
#        from_addr = 'cgithinji@mu.ac.ke'
#        recipient_list = ('admin@example.com',)
#        send_mail(subject, message, from_addr, recipient_list)
#
# signals.post_save.connect(notify_admin, sender=User)

class InstallationDate(models.Model):
    STATUS_CHOICES = (
        ('INSTALLED', 'Installed'),
        ('NOT INSTALLED', 'Not Installed'),
    )
    school = models.OneToOneField(School, on_delete=models.CASCADE)
    number_of_devices=models.CharField(max_length=3)
    planned_installation_date=models.DateField('planned')
    actual_installation_date=models.DateField('actual')
    status=models.CharField(max_length=13, choices=STATUS_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__ (self):
        return self.school.ame

reversion.register(InstallationDate)
